AMA Gaming Site - Updated project

What changed:
- Expanded the game catalogue to 66 games across 8 categories.
- Added English descriptions and Steam header artwork links for the new entries.
- Added a live game counter to category pages and search results.
- Kept the existing Home banner artwork and made its Light Mode treatment brighter; Dark Mode keeps the darker treatment.
- Right-aligned the Persian About Me section and set the font stack to B Nazanin, then Tahoma.
- Fixed the CSS media-query nesting so game-card styles work on desktop as well as mobile.

How to use:
1. Extract this ZIP to a folder.
2. Open index.html in a browser.
3. Keep an internet connection to load the remote game artwork. The Home banner is included locally.

Note about fonts:
B Nazanin must already be installed on the computer for it to display. If it is unavailable, the browser falls back to Tahoma.

Note about game ratings:
The catalogue is an informational selection. Game age ratings and content vary; check the rating in your region before playing.
